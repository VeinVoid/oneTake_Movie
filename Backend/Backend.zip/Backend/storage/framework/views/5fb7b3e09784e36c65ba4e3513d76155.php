<!DOCTYPE html>
<html lang="en">
<head>
    <title>Movie API</title>
</head>
<body>
    <nav>
        <?php echo $__env->yieldContent('navbar'); ?>
    </nav>
    <h1><?php echo $__env->yieldContent('title'); ?></h1>
    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html><?php /**PATH C:\Users\LENOVO\Documents\PPLG Sekolah\Tugas_Mobile_08_08_2023\Backend\Backend\resources\views/layout/app.blade.php ENDPATH**/ ?>