<!DOCTYPE html>
<html lang="en">
<head>
    <title>Movie API</title>
</head>
<body>
    <nav>
        @yield('navbar')
    </nav>
    <h1>@yield('title')</h1>
    <div>
        @yield('content')
    </div>
</body>
</html>